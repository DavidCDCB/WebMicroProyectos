9th January 2017

Phaser CE has now moved to its own repo: [https://github.com/photonstorm/phaser-ce](https://github.com/photonstorm/phaser-ce)

Please open all related issues and PRs against the new repo.
